#pragma once

#include "Common/Thread/ThreadManager.h"

extern ThreadManager g_threadManager;
