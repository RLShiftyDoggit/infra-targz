#pragma once

void Register_SysMemForKernel();
