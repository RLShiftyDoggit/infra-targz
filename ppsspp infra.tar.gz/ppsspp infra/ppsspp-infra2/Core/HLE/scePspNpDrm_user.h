#pragma once

class PointerWrap;

void Register_sceNpDrm();
