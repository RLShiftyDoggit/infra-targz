mkdir -p build
(cmake CMakeLists.txt && make -j5)
#cp build/atlastool /home/henrik/bin
