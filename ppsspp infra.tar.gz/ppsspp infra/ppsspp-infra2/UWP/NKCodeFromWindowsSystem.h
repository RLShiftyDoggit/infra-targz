#pragma once

#include <map>

#include "Common/Input/KeyCodes.h"

extern std::map<Windows::System::VirtualKey, InputKeyCode> virtualKeyCodeToNKCode;
