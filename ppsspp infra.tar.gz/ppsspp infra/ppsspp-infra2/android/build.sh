cmake .. && make && (cd ../jni; ../build/atlastool atlasscript.txt main; cd ../build) && make && (cd ../jni; ../build/phoenix; cd ../build)
