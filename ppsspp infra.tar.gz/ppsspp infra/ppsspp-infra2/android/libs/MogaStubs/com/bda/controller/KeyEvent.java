package com.bda.controller;

public class KeyEvent {
	public static final int ACTION_DOWN = 0;
	public static final int ACTION_UP = 1;
	public static final int KEYCODE_DPAD_UP = 2;
	public static final int KEYCODE_DPAD_DOWN = 3;
	public static final int KEYCODE_DPAD_LEFT = 4;
	public static final int KEYCODE_DPAD_RIGHT = 5;
	
	public int getAction() {
		return 0;
	}
	public int getState(int val) {
		return 0;
	}
	public int getKeyCode() {
		return 0;
	}
}
