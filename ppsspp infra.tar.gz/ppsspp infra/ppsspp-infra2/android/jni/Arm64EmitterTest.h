#pragma once

// Just a test of the ARM64 emitter, playing around with running some code without having the whole emu around.

void Arm64EmitterTest();