export NDK=/c/AndroidNDK
$NDK/ndk-gdb --nowait
