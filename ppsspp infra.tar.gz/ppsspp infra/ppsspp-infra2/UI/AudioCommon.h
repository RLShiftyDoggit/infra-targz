#pragma once

#include <cstdint>

int __AudioMix(int16_t *outstereo, int numFrames, int sampleRate);
