#pragma once

class UIContext;

#ifdef USE_PROFILER

void DrawProfile(UIContext &ui);

#endif